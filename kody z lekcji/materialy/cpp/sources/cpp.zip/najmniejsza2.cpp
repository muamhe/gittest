#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[]) {
  int  k, a, min;		// deklaracja zmiennych
  cout << "ile chcesz podac liczb - co najmniej jedna ";
  cin >> k;			// ilo�� liczb do wprowadzenia
  cout << "wprowadz liczbe ";
  cin >> a;			// wprowadzamy pierwsz� liczb�
  min = a;			// i przyjmujemy j� jako bie��ce minimum
  while (k>1)			// p�tla b�dzie si� wykonywa�a dop�ki k>1
  {
    cout << "wprowadz liczbe ";
    cin >> a;			// wprowadzamy nastepn� liczb�
    k--;			// zmniejszamy ilo�� liczb pozosta�ych do wprowadzenia
    if (a<min)   		// najwa�niejsza cze�� programu
      min = a;		
  }				// koniec p�tli
  cout << "najmniejsza wartosc w podanym ciagu to: " << min << endl;

    system("PAUSE");
    return EXIT_SUCCESS;
}
