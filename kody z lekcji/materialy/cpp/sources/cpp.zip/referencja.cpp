#include <cstdlib>
#include <iostream>

using namespace std;

void zmiany(float &zarobek, int &staz) {
	zarobek = zarobek*1.1;
	staz = staz+1;
}

int main(int argc, char *argv[]) {
	float zarobek = 1000;
	int staz=0;
	cout << "Twoj staz pracy: " << staz << " \tZarabiasz: " << zarobek << endl;
	for (int i=1; i<21; i++) {
		zmiany(zarobek,staz);
		cout << "Twoj staz pracy: " << staz << " \tZarabiasz: " << zarobek << endl;	
	}
	return 0;
}
