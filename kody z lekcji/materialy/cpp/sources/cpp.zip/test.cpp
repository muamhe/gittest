#include <cstdlib>
#include <iostream>

using namespace std;

void wypelnij (int tab[], int n, int l) {
	srand(time(NULL));
	for (int i=0; i<n; i++)
		tab[i] = rand() % l;
}

void wyswietl (int tab[], int n, string kom) {
  cout << kom << "\n";
	for (int i=0; i<n; i++)
		cout << tab[i] << " ";
	cout << endl;
}

int main(int argc, char **argv) {
	int tab[100];
	wypelnij(tab,100,2);
	wyswietl(tab,100,"Cześć");
	return 0;
}

