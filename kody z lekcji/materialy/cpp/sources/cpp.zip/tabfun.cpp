//funkcja wypełnia tabelę tab[] liczbami całkowitymi z zakresu <0;l-1>
void wypelnij (int tab[], int n, int l) {
	srand(time(NULL));
	for (int i=0; i<n; i++)
		tab[i] = rand() % l;
		
//a = (double)rand()/(RAND_MAX); - losuje liczby rzeczywiste z zakresu <0;1>
}
//funkcja wyswietla komunikat kom i zawartość tabeli tab[]
void wyswietl (int tab[], int n, string kom) {
  cout << kom << "\n";
	for (int i=0; i<n; i++)
		cout << tab[i] << " ";
	cout << endl;
}
//funkcja wypełnia tabelę tab[] wartościami podanymi przez użytkownika
void wypelnij2(int tab[], int n) {
  for (int i=0; i<rozmiar; i++) {
    cout << "Podaj wartość elementu: ";
    cin >> tab[i];
  }
}
//funkcja zamienia wartości dwóch zmiennych przekazanych przez referencję
void zamien (int &a, int &b) {
  int tmp=a;
  a=b;
  b=tmp;
}
//funkcja sortuję tabelę liczb całkowitych alg. bąbelkowym
void bubble_sort (int tab[], int n) {
  cout << "\n*-*-*-*-< Sortowanie babelkowe >-*-*-*-*\n";
  int tmp;
  for (int j=n-1; j>0; j--) {
    for (int i=0; i<j; i++)
      if (tab[i]>tab[i+1])
        zamien(tab[i],tab[i+1]);
  }
}
//funkcja sortuję tabelę liczb całkowitych alg. przez wstawianie
void insert_sort (int tab[], int n) {
  cout << "\n*-*-*-*-< Sortowanie przez wstawianie >-*-*-*-*\n";
  int i, k, el;
  for (i=1; i<n; i++) {
    el=tab[i];
    k=i-1;
    while (k>=0 && tab[k]>el) {
      tab[k+1]=tab[k];
      k--;
    }
    tab[k+1]=el;
  }
}
//funkcja sortuję tabelę liczb całkowitych alg. przez wybór
void selection_sort(int tab[], int n) {
  cout << "\n*-*-*-*-< Sortowanie przez wybor >-*-*-*-*\n";
  int i, j, k, tmp;
  for (i=0; i<n; i++) {
    k=i;
    for (j=i+1; j<n; j++)
      if (tab[j]<tab[k])
        k=j;
    zamien(tab[k],tab[i]);
  }
}
//funkcja kopiuję zawartość tabeli tab[] do tabeli tab2[]
void copytab(int tab[],int tab2[], int n) {
  for (int i=0; i<n; i++)
    tab2[i]=tab[i];
}
//funkcja wyszukuje el. w tablicy tab[]
int szukaj(int tablica[10], int szukany) {
	int i = 0;
	while (i<10 && tablica[i]!=szukany)
		i++;
	if (i==10) {
		cout << "Element nie zostal znaleziony" << endl;
		return -1;
	}
	cout << "Element zostal znaleziony" << endl;
	return i;
}
//funkcja wyszukuje el. w tablicy tab[] przy użyciu wartownika
int szukaj_wart(int tablica[11], int szukany) {
	int i=0;
	tablica[10] = szukany;
	while (tablica[i]!=szukany)
		i++;
	if (i<10) {
		cout << "Element zostal znaleziony" << endl;
		return i;
	}
	cout << "Element nie zostal znaleziony" << endl;
	return -1;
}
//funkcja wyszukuje el. maksymalny w tablicy tab[]
int maks(int tab[],int ile) {
	int max = tab[0];
	for(int i=1; i<ile; i++)
		if (tab[i]>max) max=tab[i];
	return max;
}
