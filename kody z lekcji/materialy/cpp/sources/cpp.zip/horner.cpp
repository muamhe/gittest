#include <cstdlib>
#include <iostream>

using namespace std;

float horner_it(int k, float tbwsp[], float x) {
	int i;
	float wartosc = tbwsp[0];
	for (i=1; i<k+1; i++)
		wartosc = wartosc*x+tbwsp[i];
	return wartosc;
}

// W(x) = 2x^3 + 3x^2 + 5x + 4
// W(x) = x (2x^2 + 3x + 5) +4
// W(x) = x (x (2x + 3) + 5) + 4
float horner_re(int k, float tbwsp[], float x) {
	if (k==0)
		return tbwsp[0];
	else
		return horner_re(k-1,tbwsp,x)*x+tbwsp[k];
}

int main(int argc, char *argv[]) {
	int i;
	int stopien=3;
	float x;
	// -------- SCHEMAT HORNERA
	cout << "Obliczanie wartości wielomianu dla podanych 4 współczynnikow i argumentu" << endl;
	float tbwsp[4];
	cout << "Podaj 4 współczynniki..." << endl;
	for (i=0; i<4; i++)
		cin >> tbwsp[i];
	cout << "Podaj argument... ";
	cin >> x;
	cout << "Wartość wielomianu o postaci: " << tbwsp[0] << "x^3 + " << tbwsp[1] << "x^2 + " << tbwsp[2] << "x + " << tbwsp[3] << "\ndla x = " << x << " wynosi: ";
	cout << horner_re(stopien,tbwsp,x) << endl;
	cout << horner_it(stopien,tbwsp,x) << endl;
	cout << endl;
	return 0;
}
