=============

 Program Certyfikacji ECDL prowadzony jest w Polsce przez Polskie Towarzystwo Informatyczne.

 Zapraszamy do zapoznania si� ze szczeg�ami oferty na stronie www.ecdl.com.pl

---------

 Aplikacja jest w�asno�ci� Polskiego Towarzystwa Informatycznego i jest chroniona prawem autorskim.

 Wszystkie materia�y zawarte w Aplikacji, zosta�y wykorzystane i udost�pniane s� na zasadach licencji CC-BY-NC-SA

 Tre�� test�w pr�bnych zosta�a opracowana przez egzaminator�w Krakowskiego Centrum Egzaminacyjnego (www.ecdl.malopolska.pl)

 Autorzy:
 
 Modu� 1: �ukasz Blitek, egzaminator ECDL nr PL-E2732;
 Modu� 2: Jolanta Okarmus, egzaminator ECDL nr PL-E2752;
 Modu� 3: Beata Chodacka, egzaminator ECDL nr PL-E1602;
 Modu� 4: Magdalena Wachulec, egzaminator ECDL nr PL-E3164;
 Modu� 5: Monika Skuci�ska, egzaminator ECDL nr PL-E2656;
 Modu� 6: Agata Regiewicz, egzaminator ECDL nr PL-E2507;
 Modu� 7: Maciej Jakubowski, egzaminator ECDL nr PL-E2736;
 
 Serdecznie dzi�kujemy wszystkim egzaminatorom za przygotowanie i udost�pnienie test�w pr�bnych oraz egzaminatorce Urszuli �apta� (PL-E3375) za pomoc w przygotowaniu Aplikacji.

 Instalacja Aplikacji jest mo�liwa po wcze�niejszym zainstalowaniu �rodowiska Adobe AIR, dost�pnego na stronie producenta http://get.adobe.com/air/

=============