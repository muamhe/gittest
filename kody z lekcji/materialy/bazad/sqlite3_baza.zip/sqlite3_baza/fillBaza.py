#!/usr/bin/python
# -*- coding: utf-8 -*-

import os.path
import sqlite3 as lite
import sys

con = None
bFile = 'db.sqlite3'
tabele = {
	'tbUczniowie':'Imie,Nazwisko,Plec,KlasaID,EgzHum,EgzMat,EgzJez',
	'tbOceny':'Datad,UczenID,PrzedmiotID,Ocena',
	'tbPrzedmioty':'Przedmiot,NazwiskoNaucz,ImieNaucz,PlecNaucz',
	'tbKlasy':'Klasa,RokNaboru,RokMatury',
}

if not os.path.isfile(bFile):
	print ""
	print "Baza",bFile,"nie istnieje, proszę ją utworzyć."
	print ""
	sys.exit()

def get_dane(plikcsv):
	"""Funkcja zwraca tuplę tupli zawierających dane pobrane z pliku csv do zapisania w tabeli."""
	sql = []
	if os.path.isfile(plikcsv):
		with open(plikcsv, "r") as sCsv:
			for line in sCsv:
				line=line.replace("\n","")
				line=line.decode("utf-8")
				sql.append(tuple(line.split(",")))
	else:
		print "Plik z danymi",plikcsv,"dla tabeli",tabela,"nie istnieje!"
	
	return tuple(sql)

con = lite.connect(bFile)
with con:
	cur = con.cursor()
	cur.execute('SELECT SQLITE_VERSION()')
	data = cur.fetchone()
	print "SQLite version: %s" % data
	#cur.execute('PRAGMA table_info(tbOceny)')
	#data = cur.fetchall()
	#for d in data:
	#	print d[0], d[1], d[2]
	#sys.exit()

	for tabela in tabele:
		sql = get_dane(tabela+'.csv')
		if len(sql):
			ile = len(tabele[tabela].split(","))
			ask = ",".join(["?" for i in range(ile)])
			sqlstr = "INSERT INTO "+tabela+" ("+tabele[tabela]+") VALUES("+ask+")"
			print "Wykonuję:",sqlstr
			print ""
			#print sql
			cur.executemany(sqlstr,sql)
			print "Dane zapisano!\n"
		else:
			print "Danych do tabeli",tabela,"nie zapisano!\n"

#
#try:
#	con = lite.connect(bFile)
#	cur = con.cursor()    
#	cur.execute('SELECT SQLITE_VERSION()')
#	data = cur.fetchone()
#	print "SQLite version: %s" % data
#   
#except lite.Error, e:
#   
#    print "Error %s:" % e.args[0]
#    sys.exit(1)
#    
#finally:
#  
#    if con:
#        con.close()
