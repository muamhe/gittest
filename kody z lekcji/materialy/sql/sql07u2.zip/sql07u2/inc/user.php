<?php
ini_set('session.use_cookies', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.save_path', 'sesje');
ini_set('session.gc_probability', 1);
ini_set('session.cookie_httponly', true);
//ini_set('session.cookie_secure', true);

//--- funkcje obsługi użytkownika -------------------------------
class user {
	var $uVal = 'uval';
	var $remTime = 7200;//dwie godziny
	var $remCookieDomain = '';
	var $remCookieName = 'sqlDB';
	var $keys = array('uid','nick','haslo','email','datad');
	var $dane = array();
	var $kom = array();
	
	function __construct() {
		$this->remCookieDomain = ($this->remCookieDomain == '' ? $_SERVER['HTTP_HOST'] : $this->remCookieDomain);
		if(!isset($_SESSION)) session_start();
		if(!empty($_SESSION[$this->uVal])) $this->is_user($_SESSION[$this->uVal]);
		if (isset($_COOKIE[$this->remCookieName]) && !$this->uid) {
			$u = unserialize(base64_decode($_COOKIE[$this->remCookieName]));
			$this->login($u['nick'],$u['haslo'],false,true);
		}
		if (!$this->uid && isset($_POST['loguj'])) {
			$n = clrtxt($_POST['nick']); //nazwa użytkownika
			$h = clrtxt($_POST['haslo']); //hasło użytkownika
			$this->login($n,$h,true,true);
		}
		if (isset($_GET['unlog'])) $this->logout();
	}

	function login($nick, $haslo, $remember=false, $loadUser=true) {
		$nick = rescape($nick);
		$haslo = rescape($haslo);
		if ($loadUser && $this->is_user('',$nick,$haslo)) {
			if ($remember) { // zapisanie ciasteczka
			  $cookie = base64_encode(serialize(array('nick'=>$nick,'haslo'=>$haslo,'czas'=>time())));
			  $a = setcookie($this->remCookieName,$cookie,time()+$this->remTime,'/',$this->remCookieDomain,false,true);
			}
			$this->kom[]='Witaj '.$nick.'! Zostałeś zalogowany.';
			return true;
		}
		$this->kom[]='<b>Błędny login lub hasło!</b>';
		return false;
	}

	function is_user($sid,$nick=NULL,$haslo=NULL) {
		if (!empty($nick)) {
			$qstr='SELECT * FROM users WHERE nick = \''.$nick.'\' AND haslo = \''.sha1($haslo).'\' LIMIT 1';
		} else return false;
		$ret=array();
		db_query($qstr,$ret);
		if (!empty($ret[0])) {
			$this->dane=array_merge($this->dane,$ret[0]);
			$sid=sha1($this->uid.$this->nick.session_id());
			$_SESSION[$this->uVal] = $sid;
			return true;
		}
		return false;
	}

	function logout($redirectTo = '') {
		;
	}

	function __set($k,$v) {
		$this->dane[$k]=$v;
	}
	function __get($k) {
		if (array_key_exists($k, $this->dane))
			return $this->dane[$k];
		return null;
	}

	function randomPass($length=10, $chrs = '1234567890qwertyuiopasdfghjklzxcvbnm'){
		for($i = 0; $i < $length; $i++) $pwd .= $chrs{mt_rand(0, strlen($chrs)-1)};
		return $pwd;
	}
}
//-----------------------------------------------------------------
?>
