<?php
$pages = array(
	'witam'=>'Witamy',
	'tablice'=>'Tabele',
	'baza'=>'Baza',
	'sqlcmd'=>'SQL',
	'formularz'=>'Formularz'
	);

function get_page_title($id) {
	global $pages;
	if (array_key_exists($id, $pages)) echo $pages[$id];
	else echo '';
}

function get_page_content($id) {
	global $db,$pages,$kom,$user;
	if (file_exists($id.'.html')) include($id.'.html');
	else $kom[]='Brak takiej strony ['.$id.']!';
}

function get_koms($tb) {
	global $kom;
	foreach ($tb as $k) echo '<p>'.$k.'</p>';
	foreach ($kom as $k) echo '<p>'.$k.'</p>';
}

function get_menu($id) {
	global $pages;
	foreach ($pages as $p => $tyt) {
		echo '<li><a href="?id='.$p.'">'.$tyt.'</a></li>';
	}
}

function clrtxt(&$el,$maxdl=20) {
global $code;
	if (is_array($el)) {
		return array_map('clrtxt',$el);
	} else {
		$el=trim($el);
		$el=substr($el,0,$maxdl);
		if (get_magic_quotes_gpc()) $el=stripslashes($el);
		$el=htmlspecialchars($el,ENT_QUOTES);
		return $el;
	}
}

function rescape($str) {
	if (!($isa=is_array($str))) $str=array($str);
	foreach ($str as $k => $w) $str[$k] = get_magic_quotes_gpc() ? stripslashes($w) : $w;
	if (!$isa) return $str[0]; else return $str;
}
?>
