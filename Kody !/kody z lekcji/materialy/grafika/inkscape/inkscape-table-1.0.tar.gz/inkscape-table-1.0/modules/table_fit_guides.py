#!/usr/bin/env python
"""
table.py
Table support for Inkscape

Copyright (C) 2011 Cosmin Popescu, cosminadrianpopescu@gmail.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""

import sys, os, table
sys.path.append(os.path.dirname(sys.argv[0]))

import inkex, simplepath, simpletransform, sys, re

class Table(inkex.Effect):
    def __init__(self):
        inkex.Effect.__init__(self)

    def effect(self):
        base = table.BaseTable()

        if (not base.checkGuides(self)):
            sys.stderr.write('You have to have exactly 4 guides which form a square. two at 90 degrees and two at 180 degrees. Could not continue. \n')
            return

        tables = base.getSelectedTables(self)

        if (len(tables) != 1):
            sys.stderr.write('You have to select the columns from only one table to perform this operations.\n')
            return

        _id = tables[0]

        for id, node in self.selected.items():
            base.ungroup(self, id)

        base.getTable(self, _id)
        
        mergedCells = base.splitAll(self)
        
        points = base.guidesRectangle(self)

        width = points[2] - points[0]
        height = points[3] - points[1]

        base.setTableHeight(self, height)

        base.setTableWidth(self, width)

        base.move(self, points[0], base.cell_type_column)
        base.move(self, points[1], base.cell_type_row)

        base.mergeAll(self, mergedCells)

if __name__ == '__main__':   #pragma: no cover
    e = Table()
    e.affect()
