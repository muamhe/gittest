#!/usr/bin/env python
"""
table.py
Table support for Inkscape

Copyright (C) 2011 Cosmin Popescu, cosminadrianpopescu@gmail.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""

import sys, os, table
sys.path.append(os.path.dirname(sys.argv[0]))

import inkex, simplepath, simpletransform, sys, re

class Table(inkex.Effect):
    def __init__(self):
        inkex.Effect.__init__(self)
        opts = [('-x', '--xoffset', 'string', 'xoffset', '10mm',
                 'The X offset'),
                 ('-y', '--yoffset', 'string', 'yoffset', '10mm',
                 'The Y offset'),
                ]
        for o in opts:
            self.OptionParser.add_option(o[0], o[1], action="store", type=o[2],
                                         dest=o[3], default=o[4], help=o[5])

    def effect(self):
        base = table.BaseTable()

        tables = base.getSelectedTables(self)

        if (len(tables) != 1):
            sys.stderr.write('You have to select the columns from only one table to perform this operations.\n')
            return

        _id = tables[0]

        for id, node in self.selected.items():
            base.ungroup(self, id)

        mergedCells = base.splitAll(self)

        base.getTable(self, _id)

        content = base.duplicateTable(self, _id, self.options.xoffset, self.options.yoffset)

        self.current_layer.append(inkex.etree.fromstring(content))
        mergedCells[_id + 'copy'] = mergedCells[_id]
        self.doc_ids = {}
        self.getdocids()
        base.mergeAll(self, mergedCells)

if __name__ == '__main__':   #pragma: no cover
    e = Table()
    e.affect()
