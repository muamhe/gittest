#include "adresy.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Adresy w;
    w.show();
    
    return a.exec();
}
