/********************************************************************************
** Form generated from reading UI file 'adresy.ui'
**
** Created: Wed Jun 5 11:10:22 2013
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADRESY_H
#define UI_ADRESY_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QSplitter>
#include <QtGui/QTextEdit>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Adresy
{
public:
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QGridLayout *gridLayout_2;
    QPushButton *nastBtn;
    QSpacerItem *horizontalSpacer;
    QPushButton *poprzBtn;
    QLineEdit *nazwaLine;
    QPushButton *koniecBtn;
    QLabel *adresLabel;
    QTextEdit *adresText;
    QLabel *nazwaLabel;
    QSplitter *splitter;
    QPushButton *dodajBtn;
    QPushButton *zapiszBtn;
    QPushButton *anulujBtn;
    QPushButton *edytujBtn;
    QPushButton *usunBtn;

    void setupUi(QWidget *Adresy)
    {
        if (Adresy->objectName().isEmpty())
            Adresy->setObjectName(QString::fromUtf8("Adresy"));
        Adresy->resize(477, 391);
        gridLayoutWidget = new QWidget(Adresy);
        gridLayoutWidget->setObjectName(QString::fromUtf8("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(10, 10, 451, 371));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        gridLayout_2 = new QGridLayout();
        gridLayout_2->setSpacing(6);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        nastBtn = new QPushButton(gridLayoutWidget);
        nastBtn->setObjectName(QString::fromUtf8("nastBtn"));

        gridLayout_2->addWidget(nastBtn, 0, 0, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer, 0, 1, 1, 1);

        poprzBtn = new QPushButton(gridLayoutWidget);
        poprzBtn->setObjectName(QString::fromUtf8("poprzBtn"));

        gridLayout_2->addWidget(poprzBtn, 0, 2, 1, 1);


        gridLayout->addLayout(gridLayout_2, 5, 1, 1, 1);

        nazwaLine = new QLineEdit(gridLayoutWidget);
        nazwaLine->setObjectName(QString::fromUtf8("nazwaLine"));

        gridLayout->addWidget(nazwaLine, 0, 1, 1, 1);

        koniecBtn = new QPushButton(gridLayoutWidget);
        koniecBtn->setObjectName(QString::fromUtf8("koniecBtn"));

        gridLayout->addWidget(koniecBtn, 5, 3, 1, 1);

        adresLabel = new QLabel(gridLayoutWidget);
        adresLabel->setObjectName(QString::fromUtf8("adresLabel"));

        gridLayout->addWidget(adresLabel, 4, 0, 1, 1);

        adresText = new QTextEdit(gridLayoutWidget);
        adresText->setObjectName(QString::fromUtf8("adresText"));

        gridLayout->addWidget(adresText, 4, 1, 1, 1);

        nazwaLabel = new QLabel(gridLayoutWidget);
        nazwaLabel->setObjectName(QString::fromUtf8("nazwaLabel"));

        gridLayout->addWidget(nazwaLabel, 0, 0, 1, 1);

        splitter = new QSplitter(gridLayoutWidget);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Vertical);
        dodajBtn = new QPushButton(splitter);
        dodajBtn->setObjectName(QString::fromUtf8("dodajBtn"));
        splitter->addWidget(dodajBtn);
        zapiszBtn = new QPushButton(splitter);
        zapiszBtn->setObjectName(QString::fromUtf8("zapiszBtn"));
        splitter->addWidget(zapiszBtn);
        anulujBtn = new QPushButton(splitter);
        anulujBtn->setObjectName(QString::fromUtf8("anulujBtn"));
        splitter->addWidget(anulujBtn);
        edytujBtn = new QPushButton(splitter);
        edytujBtn->setObjectName(QString::fromUtf8("edytujBtn"));
        splitter->addWidget(edytujBtn);
        usunBtn = new QPushButton(splitter);
        usunBtn->setObjectName(QString::fromUtf8("usunBtn"));
        splitter->addWidget(usunBtn);

        gridLayout->addWidget(splitter, 4, 3, 1, 1);


        retranslateUi(Adresy);

        QMetaObject::connectSlotsByName(Adresy);
    } // setupUi

    void retranslateUi(QWidget *Adresy)
    {
        Adresy->setWindowTitle(QApplication::translate("Adresy", "Adresy", 0, QApplication::UnicodeUTF8));
        nastBtn->setText(QApplication::translate("Adresy", "Nast\304\231pny", 0, QApplication::UnicodeUTF8));
        poprzBtn->setText(QApplication::translate("Adresy", "Poprzedni", 0, QApplication::UnicodeUTF8));
        koniecBtn->setText(QApplication::translate("Adresy", "Koniec", 0, QApplication::UnicodeUTF8));
        adresLabel->setText(QApplication::translate("Adresy", "Adresy", 0, QApplication::UnicodeUTF8));
        nazwaLabel->setText(QApplication::translate("Adresy", "Nazwa", 0, QApplication::UnicodeUTF8));
        dodajBtn->setText(QApplication::translate("Adresy", "Dodaj", 0, QApplication::UnicodeUTF8));
        zapiszBtn->setText(QApplication::translate("Adresy", "Zapisz", 0, QApplication::UnicodeUTF8));
        anulujBtn->setText(QApplication::translate("Adresy", "Anuluj", 0, QApplication::UnicodeUTF8));
        edytujBtn->setText(QApplication::translate("Adresy", "Edytuj", 0, QApplication::UnicodeUTF8));
        usunBtn->setText(QApplication::translate("Adresy", "Usu\305\204", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Adresy: public Ui_Adresy {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADRESY_H
