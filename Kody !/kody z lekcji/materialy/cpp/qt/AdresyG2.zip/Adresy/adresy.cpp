#include "adresy.h"
#include "ui_adresy.h"

Adresy::Adresy(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Adresy)
{
    ui->setupUi(this);
    koniecBtn = new QPushButton;
    koniecBtn = ui->koniecBtn;
    koniecBtn->setEnabled(true);

    connect(koniecBtn,SIGNAL(clicked()),this,SLOT(koniec()));
}

Adresy::~Adresy()
{
    delete ui;
}

void Adresy::koniec() {
    Adresy::close();
}
