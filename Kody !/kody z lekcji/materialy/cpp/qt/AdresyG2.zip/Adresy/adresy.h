#ifndef ADRESY_H
#define ADRESY_H

#include <QWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QTextEdit>

namespace Ui {
class Adresy;
}

class Adresy : public QWidget
{
    Q_OBJECT
    
public:
    explicit Adresy(QWidget *parent = 0);
    ~Adresy();

public slots:
    void koniec();
    
private:
    Ui::Adresy *ui;
    QPushButton *dodajBtn;
    QPushButton *zapiszBtn;
    QPushButton *anulujBtn;
    QPushButton *poprzBtn;
    QPushButton *nastBtn;
    QPushButton *edytujBtn;
    QPushButton *usunBtn;
    QPushButton *koniecBtn;
    QLineEdit *nazwaLine;
    QTextEdit *adresText;
};

#endif // ADRESY_H
